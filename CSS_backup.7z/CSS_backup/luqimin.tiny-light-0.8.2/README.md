# Tiny Light

## Notice

* Imported originally from h5builder (Soft Green Theme - the best theme for your eyes)

* Some features copied from vscode solarized color theme

## ScreenShot

![ScreenShot](https://i0.letvimg.com/lc04_fe/201705/11/14/03/s1.png)

**Enjoy!**