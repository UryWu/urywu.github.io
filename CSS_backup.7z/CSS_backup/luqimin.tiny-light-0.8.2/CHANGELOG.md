# Change Log

## 0.8.0 | 2021.06.02
- add terminal theme

## 0.7.2 | 2017.07.26
- add editor indent lines color

## 0.7.0 | 2017.07.25
- add workbench button color
- use jetbrain darcula theme as the integrated console theme 

## 0.6.1 | 2017.05.11
- add screenshot

## 0.6.0 | 2017.05.10
- add icon

## 0.5.0 | 2017.05.10
- ^.^

## 0.4.0 | 2017.05.07
- Some bugs fixed

## 0.3.0 | 2017.05.07
- Some bugs fixed

## 0.0.2 | 2017.05.07
- Add workbench color copied from vscode color theme 'Solarized Light'

## 0.0.1 | 2017.05.06
- Initial release
