# MouseInc

鼠标手势-自定义手势功能

内 MouseInc.Settings.zip 文件为离线界面包，无需解压

如果你还没有webview2，前往这里下载：

https://developer.microsoft.com/zh-cn/microsoft-edge/webview2/#download-section

